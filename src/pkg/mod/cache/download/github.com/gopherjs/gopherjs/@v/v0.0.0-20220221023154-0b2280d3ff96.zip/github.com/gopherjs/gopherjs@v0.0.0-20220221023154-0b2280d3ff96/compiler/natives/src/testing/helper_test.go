//go:build js
// +build js

package testing
