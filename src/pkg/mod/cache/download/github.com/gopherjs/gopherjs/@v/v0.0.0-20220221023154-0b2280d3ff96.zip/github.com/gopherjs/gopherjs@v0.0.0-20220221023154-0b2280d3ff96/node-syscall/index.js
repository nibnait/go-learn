module.exports = require('./build/Release/syscall')
