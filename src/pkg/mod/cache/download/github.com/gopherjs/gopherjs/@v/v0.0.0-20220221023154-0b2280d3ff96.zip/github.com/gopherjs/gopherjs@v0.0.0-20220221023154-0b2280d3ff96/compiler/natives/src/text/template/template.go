//go:build js
// +build js

package template

const maxExecDepth = 3000
