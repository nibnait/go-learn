package otherpkg

var Test float32
