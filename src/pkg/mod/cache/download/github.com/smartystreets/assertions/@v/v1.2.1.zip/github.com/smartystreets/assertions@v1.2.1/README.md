[![Build Status](https://travis-ci.org/smartystreets/assertions.svg?branch=master)](https://travis-ci.org/smartystreets/assertions)
[![Code Coverage](https://codecov.io/gh/smartystreets/assertions/branch/master/graph/badge.svg)](https://codecov.io/gh/smartystreets/assertions)
[![Go Report Card](https://goreportcard.com/badge/github.com/smartystreets/assertions)](https://goreportcard.com/report/github.com/smartystreets/assertions)
[![GoDoc](https://godoc.org/github.com/smartystreets/assertions?status.svg)](http://godoc.org/github.com/smartystreets/assertions)
